function h=huniform(p,varargin)

%   Copyright (C) 2004-2012 Per-Olof Persson. See COPYRIGHT.TXT for details.

h=ones(size(p,1),1);
